export const SURVEYS: Survey = <Survey>{
    id: 123,
    nazwa: "Sondaż Abjdk",
    dataUtw: "11-22",
    dataRozp: string,
    dataZak: string,
    statusSondazu: string,
    statusSondazuEnum: number,
    semestrId: number
};
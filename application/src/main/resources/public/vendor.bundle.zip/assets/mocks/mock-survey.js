"use strict";
exports.SURVEYS = {
    id: 123,
    nazwa: "Sondaż Abjdk",
    dataUtw: "11-22",
    dataRozp: string,
    dataZak: string,
    statusSondazu: string,
    statusSondazuEnum: number,
    semestrId: number
};
//# sourceMappingURL=mock-survey.js.map